---
name: implementation_ad
description: Automates ad integration with complete logic. Updates JSON configs and generates strict Kotlin code for AdsManager, AdRemoteConfig, and Activities.
---

# Implementation Ad Skill

# Usage
To use this skill, simply request the implementation of ads and provide the list of Ad IDs (Real).

**Example Prompt:**
> "Please implement ads using the following list:
> interstitial inter_splash ca-app-pub-xxx/yyy
> native native_home ca-app-pub-xxx/zzz"

or use the command:
> `/implementation_ad <list_of_ads>`

The Agent will automatically:
1.  Update `ad_config.json` (Real IDs) and `ad_config_debug.json` (Test IDs).
2.  Generate Kotlin code for `AdRemoteConfig`, `AdsManager`, and Activities based on the templates in `implementation/`.

## 1. Update Configuration (JSON)
1.  **Parse User Input**: Extract Key (e.g., `native_home`), Type (e.g., `native`), and Real ID.
2.  **Update `app/src/main/assets/ad_config.json`**: Set `id` to the **Real ID**.
3.  **Update `app/src/main/assets/ad_config_debug.json`**: Set `id` to the **Test ID** matching the type.
    *   **Banner**: `ca-app-pub-3940256099942544/6300978111`
    *   **Interstitial**: `ca-app-pub-3940256099942544/1033173712`
    *   **Native**: `ca-app-pub-3940256099942544/2247696110`
    *   **App Open**: `ca-app-pub-3940256099942544/3419835294`
    *   **Rewarded**: `ca-app-pub-3940256099942544/5224354917`

## 2. Implement Logic (Kotlin)

### Reference Files
The full implementation templates are available in the `implementation/` folder of this skill:
- `implementation/AdsManager.kt`
- `implementation/AdRemoteConfig.kt`
- `implementation/AdRemoteConfigExtensions.kt`

### Step A1: Update `AdRemoteConfig.kt`
Template: `implementation/AdRemoteConfig.kt`
Target: `app/src/main/java/com/infinity/videomaker/ads/AdRemoteConfig.kt`

For **EACH** new ad key, add a property getter in the class:
```kotlin
    val <key_name>: AdUnitConfig
        get() = getAdUnit("<key_name>")
```

### Step A2: Update/Create `AdRemoteConfigExtensions.kt`
Template: `implementation/AdRemoteConfigExtensions.kt`
Target: `app/src/main/java/com/infinity/videomaker/ads/AdRemoteConfigExtensions.kt`

If this file exists, add the extension property. If not, create it using the template.

```kotlin
val AdRemoteConfig.Companion.<key_name>: AdUnitConfig
    get() = getInstance().<key_name>
```
*Example:*
```kotlin
    val native_home_screen: AdUnitConfig
        get() = getAdUnit("native_home_screen")
```

### Step B: Update `AdsManager.kt`
Template: `implementation/AdsManager.kt`
Target: `app/src/main/java/com/infinity/videomaker/ads/AdsManager.kt`

**IMPORTANT**: AdsManager uses `MutableLiveData<ApNativeAd?>` pattern. Each native ad slot has its own LiveData.

For **EACH** new ad, follow the pattern based on type:

**1. Native Ad - Add LiveData variable + load function:**

First, add a LiveData declaration at the top of the object:
```kotlin
    val <variableName>AdLive = MutableLiveData<ApNativeAd?>()
```

Then add a load function that calls `loadNativeInternal`:
```kotlin
    fun load<Name>(activity: Activity, layoutRes: Int) {
        loadNativeInternal(activity, AdRemoteConfig.<key_name>, layoutRes, <variableName>AdLive)
    }
```

**2. Native Ad with isFirst variant (e.g., language, onboarding):**
```kotlin
    fun load<Name>(activity: Activity, isFirst: Boolean, layoutRes: Int) {
        val config = if (isFirst) AdRemoteConfig.<key_name_1> else AdRemoteConfig.<key_name_2>
        loadNativeInternal(activity, config, layoutRes, <variableName>AdLive)
    }
```

**3. Interstitial Ad - Add private var + load/show functions:**
```kotlin
    private var <variableName>Ad: ApInterstitialAd? = null

    fun load<Name>(context: Context) {
        val config = AdRemoteConfig.<key_name>
        if (!config.isEnable || AppPurchase.getInstance().isPurchased(context)) {
            <variableName>Ad = null
            return
        }
        <variableName>Ad = NkhAd.getInstance().getInterstitialAds(context, config.id, object : AdCallback() {})
    }
```

**4. Update `clearAll()` function:**
- For native LiveData: add `<variableName>AdLive.postValue(null)`
- For interstitial: add `<variableName>Ad = null`

**5. Key behavior of `loadNativeInternal`:**
- It checks `config.isEnable`, `isPurchased`, and `isNetworkAvailable`
- On failure: posts `null` to the LiveData
- On success: stores `nativeAd -> config` mapping in `adConfigMap`, then posts the ad to LiveData
- The `adConfigMap` allows callers to resolve which config was used: `AdsManager.getAdConfig(ad)`

### Step C: Update Activities
File: Target Activity (e.g., `HomeActivity.kt`)

**Note:** If the target Activity **does not exist yet**, SKIP this step. The infrastructure (`AdRemoteConfig`, `AdsManager`) is still prepared for future use.

**In `initViews` or `checkRemoteConfigResult`:**
```kotlin
    // Load the ad
    AdsManager.load<Name>(this, R.layout.<layout_name>)

    // Observe the LiveData to show the ad
    AdsManager.<variableName>AdLive.observe(this) { nativeAd ->
        if (nativeAd != null) {
            // Show the native ad in your view
        }
    }
```

## 3. Verification
1.  Check JSON files for correct IDs.
2.  Check `AdRemoteConfig.kt` has the new key.
3.  Check `AdsManager.kt` has the new load function and LiveData.
4.  Build project to verify strict typing.
