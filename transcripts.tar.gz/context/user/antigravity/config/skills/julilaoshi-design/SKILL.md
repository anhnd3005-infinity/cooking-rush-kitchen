---
name: julilaoshi-design
description: Public-safe julilaoshi-design workflow for official Pencil/OpenPencil MCP execution and free browser-first julilaoshi-design Web 2.0 editor. Use when a task needs Pencil/OpenPencil handshake/canvas edits, .pen/.op execution, screenshot review, vibrant light mode UI, or lightweight HTML design-to-web tweaking.
---

# julilaoshi-design Workflow & Permanent Rules

## Core Guidelines

1. **Vibrant & Light-Mode First Aesthetics:**
   - Default UI visual generation to **Vibrant Light Mode** (soft white `#F8FAFC`, pastel mesh gradient auras, electric indigo/coral accents, 3D iridescent glass spheres) unless dark mode is explicitly requested.

2. **Pencil MCP Frame Image Insertion:**
   - When generating high-fidelity AI visual mockups (`generate_image`), always copy the output to the project assets folder and insert directly into the active `.pen` canvas via Pencil MCP `execute` using frame fill:
     ```javascript
     Insert(document, {
       type: "frame",
       name: "AI Generated UI Mockup",
       width: 390,
       height: 844,
       borderRadius: 40,
       clip: true,
       fill: { type: "image", url: "file:///absolute/path/to/asset.jpg", mode: "fill" }
     });
     ```

3. **Flaticon CDN Icon Integration:**
   - Fetch real vector icons directly from Flaticon CDN (`cdn-icons-png.flaticon.com`) via `flaticon-mcp` tools instead of using placeholder shapes.

4. **Modes:**
   - **Mode A (Pencil / OpenPencil MCP Mode):** Native `.pen` and `.op` vector layout execution, node manipulation, and screenshot review (`get_screenshot`).
   - **Mode B (Web 2.0 Free Browser Editor Mode):** Standalone static HTML/JS drag-and-drop editor (`web_editor.html`).
