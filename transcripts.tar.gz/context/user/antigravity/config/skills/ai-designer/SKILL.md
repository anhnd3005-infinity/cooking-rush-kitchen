---
name: ai-designer
description: Global AI Product Designer skill for Antigravity. Automatically designs UI/UX screens, generates Vibrant Light Mode 8K visual mockups, executes Pencil MCP canvas updates, and outputs production developer handoffs. Activate when the user types /design or asks for UI design, Pencil edits, or mockup generation.
---

# Global AI Designer Skill

## Overview
Automates complete UI/UX creation pipeline combining Gemini Image Generator (`generate_image`), Pencil MCP Server (`pencil/execute`, `pencil/get_screenshot`), Flaticon MCP, and OpenPencil (`.op`) Design-as-Code engine.

## Usage Rule
Whenever the user uses `/design` or asks for UI design:
1. Default to **Vibrant Light Mode** aesthetics (Soft White `#F8FAFC`, Pastel Mesh Gradient, Electric Indigo & Coral accents).
2. Generate high-fidelity mockup via `generate_image`.
3. Insert image frame into active `.pen` canvas via `pencil/execute`.
4. Capture screenshot via `pencil/get_screenshot` for visual verification.
