---
name: figma-hig-pro-max
description: Enterprise Figma Design System & Apple HIG iOS 27 UI/UX Architecture Skill combining UI UX Pro Max (BM25 Intelligence Engine), FlowKitMCP Batch AI Visual Studio, Official Figma MCP Library Generation, Taste-Design Anti-Slop Standards, Visual-First Single-Metric Copy (Zero Text/Coordinate Clutter), Unified Single-Source Vector Iconography, Pixel-Accurate Bounding-Box Centering, and Scrollable Hub Ergonomics for `figma_mcp_design`.
---

# Figma HIG Pro Max (v2.4) — Full-Stack Apple HIG + FlowKitMCP + Visual-First Design System Skill

This skill synthesizes the complete **5-Engine Design Ecosystem** with battle-tested production refinements from real multi-screen iOS 27 design systems (`59+ screens`) for `figma_mcp_design`:
1. **`ui-ux-pro-max` (BM25 Design Intelligence Engine)**: Searches 79+ UI styles, 192+ product color palettes, 74+ font pairings, and 119+ Apple HIG / SwiftUI UX guidelines.
2. **`FlowKitMCP` (`/gen_image` & Batch AI Asset Studio)**: Generates photorealistic 3D satellite renders, 8K street photography, onboarding heroes, and ceramic/titanium instrument dials (`flowkit_health` -> `flowkit_create_project` -> `flowkit_batch_generate` -> `flowkit_wait_for_batch`) with **100% Zero Baked-In Text**.
3. **`figma-generate-library` & `figma-swiftui`**: Registers Native Figma Variable Collections (`COLOR`, `FLOAT`), Semantic Token Bindings (`bind_variable_to_node`), Local Styles (`Text`, `Paint`, `Effect`, `Grid`), and W3C DTCG Token Exports (`export_tokens`).
4. **`lucide-static` Swift Vector Icon Rasterizer (`render_clean_flaticons.swift`)**: Renders 100% uniform `1.85px` stroke vector icons with transparent backgrounds (zero mixed packs, zero colored wrapper boxes).
5. **`taste-design` + Visual-First Anti-Slop Guardrails (v2.4)**:
   - **Single-Metric / Single-Clause Copy (`compact_text`)**: Maximum 1 short Title (`2–3 words`) + 1 concise Subtitle (`2–3 words`); 1 metric only on status lines (`● 1,890 watching` — NEVER `● 1,890 watching · 4K HDR Stream`).
   - **Zero Raw GPS Coordinates (`40.7484° N...`) on UI Cards**: Always use human-readable Place/City names (`New York, USA`, `Tokyo, Japan`, `Rome, Italy`).
   - **Visual `2×2` Photo Bento Grids + `1×4` Single-Word Tool Docks** instead of stacked text-heavy horizontal banners.
   - **Empirical Bounding-Box Text Centering (`absoluteBoundingBox`)** & **Synchronized 4-Cue Bottom TabBar Active State**.

---

## Phase 1: Design Intelligence Query (`ui-ux-pro-max`)

Before creating or upgrading a Figma design system, query the `ui-ux-pro-max` BM25 search engine:

```bash
python3 ~/.gemini/config/skills/ui-ux-pro-max/scripts/search.py "<product_domain_keywords>" --design-system -p "<Project Name>"
python3 ~/.gemini/config/skills/ui-ux-pro-max/scripts/search.py "apple hig light mode typography touch target" --domain ux
python3 ~/.gemini/config/skills/ui-ux-pro-max/scripts/search.py "navigation sheet toolbar tabbar" --stack swiftui
```

---

## Phase 2: AI Visual Asset Generation Studio (`FlowKitMCP` + `image-generator` Fallback)

Never use synthetic CoreGraphics vector scribbles or text-heavy placeholder banners for maps, 3D globes, camera viewfinders, or product photography.

1. **Health Check & Project Setup (`FlowKitMCP`)**:
   - Call `flowkit_health` first to verify connection to `http://127.0.0.1:8100` and Chrome extension status.
   - Create or select a project via `flowkit_create_project` / `flowkit_list_projects`.
2. **Batch Generation (`flowkit_batch_generate` + `flowkit_wait_for_batch`)**:
   - Submit photorealistic asset prompts in batches (`GENERATE_IMAGE`, max 5 concurrent, auto-throttled) and poll with `flowkit_wait_for_batch`.
   - **Fallback**: If the local FlowKit agent (`127.0.0.1:8100`) is offline, automatically fall back to the `image-generator` subagent so asset generation never blocks.
3. **Mandatory FlowKit Prompt Guardrails (Zero Baked-In Text)**:
   - Every FlowKit prompt MUST end with:
     `"pure photorealistic visual photography / 3D render, zero text, zero typography, zero UI overlays, zero watermarks, vibrant daylight lighting, 8k detail"`
   - **Why**: Baked-in text inside AI-generated thumbnails collides with Figma typography and creates messy double-captions.
4. **Dedicated FlowKit AI Asset Studio Section on Canvas (`build_le_sec8_flowkit_batch.py`)**:
   - Mount all 24+ FlowKit master assets into a dedicated showcase section (`09. FLOWKIT AI ASSET STUDIO`) and clone them across all screens using `flush_deferred_photos()`.

---

## Phase 3: Native Figma Variable Collection & Semantic Token Binding (`figma-generate-library`)

Always register a local `VariableCollection` and bind core canvas frames and components using `figma_mcp_design`:

1. **Create Collection (`create_variable_collection`)**:
   - Name: `Apple HIG iOS 27 — Light Mode Tokens` (`initialModeName: "Light Mode"`)
2. **Register Semantic Variables (`create_variable`)**:
   - **Surface Tokens (`COLOR`)**:
     - `Surface/Canvas-Light`: `#EEF6F8` / `#F2F2F7` (iOS `systemGroupedBackground`)
     - `Surface/Card-Elevated`: `#FFFFFF` (iOS `secondarySystemGroupedBackground`)
     - `Surface/Group-Subtle`: `#F1F7F9` (Secondary grouped card fill)
     - `Surface/Active-Tint`: `#CCFBF1` (Active Pill & Selection Tint)
   - **Text & Label Tokens (`COLOR`)**:
     - `Text/Primary-Ink`: `#0F172A` (High-contrast slate ink)
     - `Text/Secondary-Slate`: `#475569` (Readable body & metadata)
     - `Text/Muted-Tertiary`: `#64748B` (Inactive tab & caption)
   - **Brand & Semantic Accent Tokens (`COLOR`)**:
     - `Accent/Primary-Teal`: `#0D9488`
     - `Accent/Primary-Deep`: `#0F766E`
     - `Accent/Primary-Border`: `#5EEAD4`
     - `Semantic/Live-Rose`: `#E11D48`
     - `Semantic/Solar-Amber`: `#D97706`
     - `Semantic/Sky-Blue`: `#0284C7`
   - **Spatial, Radius & Ergonomic Tokens (`FLOAT`)**:
     - `Radius/Card-24`: `24`, `Radius/Sheet-30`: `30`, `Radius/Pill-32`: `32`
     - `Space/Grid-8`: `8`, `Space/Inset-16`: `16`, `Touch/Min-Target-44`: `44`
3. **Bind Variables to Nodes (`bind_variable_to_node`)**:
   - Bind `fillColor`, `strokeColor`, and `cornerRadius` on screen frames, cards, and component masters.

---

## Phase 4: Native Figma Local Styles (`Text`, `Paint`, `Effect`, `Grid`)

Register Local Styles so the right-hand Figma Inspector panel is 100% structured:
- **Text Styles (`create_text_style`)** — Note: use `"Semi Bold"` (with a space) for `Inter` in Figma:
  - `HIG/Large Title (26 Bold)` — `26px`, `Bold`, line-height `32px`, tracking `-0.5px`
  - `HIG/Title 1 (22 Bold)` — `22px`, `Bold`, line-height `28px`, tracking `-0.4px`
  - `HIG/Title 2 (18 Bold)` — `18px`, `Bold`, line-height `24px`, tracking `-0.3px`
  - `HIG/Headline (15 Semi Bold)` — `15px`, `Semi Bold`, line-height `20px`
  - `HIG/Body (13 Regular)` — `13px`, `Regular`, line-height `19px`
  - `HIG/Subheadline (12 Medium)` — `12px`, `Medium`, line-height `16px`
  - `HIG/Caption (11 Bold)` — `11px`, `Bold`, line-height `14px`
  - `HIG/Tab Label (10 Bold)` — `10px`, `Bold`, line-height `12px`
- **Effect Styles (`create_effect_style`)**:
  - `HIG Elevation/Card Subtle` (`DROP_SHADOW`, `offsetY: 4`, `radius: 12`, `opacity: 0.05`)
  - `HIG Elevation/Floating Glass Bar` (`DROP_SHADOW`, `offsetY: 8`, `radius: 24`, `opacity: 0.08`)
  - `HIG Elevation/Modal Sheet` (`DROP_SHADOW`, `offsetY: -4`, `radius: 28`, `opacity: 0.10`)

---

## Phase 5: The 9 Production Anti-Slop Guardrails (Lessons Learned from Real User Reviews)

Every screen generated by this skill MUST enforce these 9 mandatory guardrails:

### 1. Visual-First Layout (`2×2` Photo Bento Grids & `1×4` Single-Word Tool Docks)
- **NEVER Stack Full-Width Text List Cards on Home/Explore Hubs**:
  - Stacking 3–4 full-width horizontal cards filled with multi-line descriptions creates a "wall of text" (`quá nhiều chữ`).
  - **Always use Visual Photo Bento Grids (`2×2`, `174 × 150px`)** for feature sections (`3D EXPLORE`, `SPACE & AI`), where **70% of each card is a clean FlowKit photo thumbnail (`158 × 92px`, zero baked-in banner text)** and the bottom has ONLY a **2-word Title (`14px Bold`) + 2-word Subtitle (`11px Medium`)** + 1 vector icon (`20×20px`).
  - **Use a `1×4` Single-Word Icon Tile Row (`82 × 58px` per tile)** for quick utilities (`TOOLS`: `Traffic`, `Wonders`, `Compass`, `Weather`) — **1 centered vector icon + 1 single word**, **ZERO subtitles and ZERO chevrons**.

### 2. Single-Metric Copy (`compact_text`) & Zero Raw GPS Coordinates (`40.7484° N...`)
- **NEVER Chain Multiple Metadata Clauses with `" · "` on a Single Line**:
  - Every text line inside a card, media row, or list row MUST contain **at most 1 concise metric or fact**.
  - **Media/Webcam Row Example (`15_Video_Live_Favorites`)**:
    - **Title (`14px SemiBold`)**: Place/Feature name only (`"Times Square"`, `"Shibuya Crossing"` — NEVER `"Times Square North Cam"`).
    - **Subtitle (`12px Regular`)**: City & Country only (`"New York, USA"`, `"Tokyo, Japan"` — NEVER `"New York, USA · 09:41 AM EDT"`).
    - **Status / Meta Line (`11px SemiBold`)**: 1 primary metric only (`"● 1,890 watching"` — NEVER `"● 1,890 watching · 4K HDR Stream"` or `"● Online · 1.8K Viewers · 19°C"`).
- **NEVER Show Raw Decimal/DMS GPS Coordinates (`40.7484° N, 73.9857° W`) on Cards or Rows**:
  - Raw coordinates (`40.7484° N, 73.9857° W`, `40°45'28.8"N`, `87G8Q257+6Q`, `WGS84`) are robotic clutter (`thừa`).
  - Always use human-readable Place/City names (`"New York, USA"`, `"Manhattan, NY"`, `"Rome, Italy"`), or omit the subtitle completely when the screen header already specifies the city (e.g. `12_Video_Live_Cluster_Sheet`: 2 lines only — `Empire State` + `● 1,100 watching`).
- **Strict Clean-Canvas Rule (Zero Annotation Bloat by Default)**:
  - **NEVER place text-heavy explanation cards (`NavCard_*`), bullet-point callout boxes, or floating text pills around/underneath UI screens by default.**

### 3. Single-Source Vector Iconography (Zero Mixed Packs, Zero Box Wrappers)
- Render 100% of UI, navigation, feature, and tabbar icons from **one single vector library** (`lucide-static` SVGs rendered with `stroke-width: 1.85px`, round caps/joins, transparent background).
- NEVER wrap standalone row, card, or utility icons inside colored square/circle background boxes (`IconBadge_*`). Place the crisp transparent vector icon directly on the card surface (`#0D9488` primary accent for active/feature icons; `#64748B` slate for inactive tabbar icons).

### 4. Clean CTA Buttons & Card Surfaces (Zero `GlassBtnSheen`, Zero Corner `Chip_*`)
- Primary CTA buttons (`add_Action_button`) must be a clean solid pill/rounded-rect (`fill=#0D9488`, `radius=25`, `stroke=#2DD4BF`, `stroke_weight=1.5`) with a centered `Bold` white label (`2–4 words`). **NEVER add a translucent white `GlassBtnSheen` rectangle inside CTA buttons**.
- Keep card top-right corners clean. **NEVER stack decorative status chips (`Chip_LIVE`, `Chip_3D`, `Chip_PRO`) in the top-right corner of feature/list cards**.

### 5. Empirical Bounding-Box Text Centering & Safe Right Margins
- After creating or updating any centered text node inside a Button, Segmented Control tab, Pill Badge, or Bottom TabBar slot, query `get_nodes_info` for `absoluteBoundingBox.width` (`cw`) and `height` (`ch`), then call `move_nodes`:
  ```python
  exact_x = round(box_x + (box_w - cw) / 2.0, 1)
  exact_y = round(box_y + (box_h - ch) / 2.0, 1)
  ```
- In list rows and media rows, maintain a clean `16px` gap between thumbnail right edge and text (`text_x = thumb_x + thumb_w + 16`) and reserve `38px` on the right for the chevron `›`.

### 6. Synchronized 4-Cue Bottom TabBar Active State
- Every screen that includes `BottomTabBar_LiquidGlass` MUST pass the exact `active` index matching its section (`0 = Explore`, `1 = Earth 3D`, `2 = GPS Cam`, `3 = Tools`) with 4 visual cues: `TabActivePill` (`#CCFBF1`), active icon (`#0D9488`), centered `Bold` label (`#0F766E`), and `TabActiveDot` (`22×3px`).

### 7. Spacious Scrollable Home Hub (`393 × 1340px`) Over Cramped `852px` Frames
- Build multi-zone Home screens as a breathable vertical-scroll frame (`393 × 1340px`) with generous whitespace (`24px` vertical gaps), visual `2×2` Bento grids, and a `1×4` single-word Tools dock.

### 8. Status Bar Overlay Protection on Full-Bleed Map/Camera Screens
- Call `add_status_bar_overlay(scr, light_text=True)` **after** importing any full-bleed background image at `y = 0` so `9:41`, `DynamicIsland`, and `5G 100%` remain visible.

### 9. Master-Clone Photo Pipeline (`flush_deferred_photos`)
- Upload each FlowKit master photo once into `00. MASTER DESIGN SYSTEM`, store its node ID in `le_master_cache.json`, and populate screen image slots by cloning the master node (`clone_node` + `resize_nodes` + `move_nodes`).

---

## Bundled Extensions (`extensions/figma-plugin` & `extensions/flowkit`)

This skill repository bundles **both required extensions and their MCP servers** out-of-the-box under `extensions/`:

1. **Figma Desktop Extension & `figma_mcp_design` Server (`extensions/figma-plugin/`)**:
   - **Figma Plugin Manifest**: `extensions/figma-plugin/plugin/manifest.json` (pre-built bundle in `extensions/figma-plugin/plugin/dist/main.js` & `index.html`, plus `figma_design_plugin.zip`).
   - **How to Load in Figma Desktop**: `Plugins` -> `Development` -> `Import plugin from manifest...` -> select `extensions/figma-plugin/plugin/manifest.json`.
   - **MCP Server Source**: `extensions/figma-plugin/cmd/figma-mcp-design` & `internal/` (listens on WebSocket port `3055` for the Figma plugin and HTTP RPC port `1995` for fast batch scripts).

2. **FlowKit Chrome Extension & `FlowKitMCP` Agent (`extensions/flowkit/`)**:
   - **Chrome Extension Folder**: `extensions/flowkit/extension/` (`manifest.json`, `background.js`, `content.js`, `popup.html`, `side_panel.html`, plus `flowkit_chrome_extension.zip`).
   - **How to Load in Chrome**: Open `chrome://extensions` -> enable **Developer mode** -> click **Load unpacked** -> select `extensions/flowkit/extension`.
   - **FlowKit Local Agent & MCP Server**: `extensions/flowkit/agent/` & `tools/mcp_server.py` (runs at `http://127.0.0.1:8100` via `python -m agent.main`).

---

## Included Reference Scripts & Docs

- [`references/lessons-learned-ios27-live-earth.md`](references/lessons-learned-ios27-live-earth.md): Detailed before/after engineering post-mortem of all 9 UI/UX refinements.
- [`scripts/le_engine.py`](scripts/le_engine.py): Core Python engine for `figma_mcp_design` HTTP RPC, `compact_text` single-metric enforcement, bounding-box text centering, 4-cue Bottom TabBar, and master-clone image pipeline.
- [`scripts/build_le_sec8_flowkit_batch.py`](scripts/build_le_sec8_flowkit_batch.py): FlowKit AI Asset Studio builder & master-clone batch photo mounter (`24+ FlowKit photorealistic 3D & satellite assets`).
- [`scripts/render_clean_flaticons.swift`](scripts/render_clean_flaticons.swift): Swift + AppKit SVG rasterizer that converts `lucide-static` SVGs into a 100% uniform `1.85px` stroke transparent PNG icon library.
- [`scripts/build_le_scrollable_home_and_new_features.py`](scripts/build_le_scrollable_home_and_new_features.py): Clean visual-first reference builder for `09_Home_Explore_Hub` (`2×2` Bento + `1×4` Tools) and `56`–`59`.
- [`scripts/apply_live_figma_v10_clean_all.py`](scripts/apply_live_figma_v10_clean_all.py) & [`scripts/remove_all_coords_and_3rd_lines.py`](scripts/remove_all_coords_and_3rd_lines.py): Live Figma canvas cleaners that strip annotation bloat, chained `" · "` clauses, raw GPS coordinates, and redundant 3rd text lines in-place.
