---
name: android-layout-template-design
description: Use when generating or modifying Android XML layouts (standard screen UI or native ads templates) for the base template project to ensure consistent styling, DataBinding usage, SDP/SSP responsiveness, and dynamic reordering compliance.
---

# Android XML Layout Template Design

## Overview
This skill provides the structure, rules, and style tokens to generate and modify XML layout files in the `template-base-code` repository. It covers both normal screen layouts and dynamic native ads layouts to maintain UI consistency and support responsive scaling.

## Core Guidelines

### 0. Strict Rule Against Hardcoded Strings
- **No hardcoded text**: All user-facing text attributes (e.g., `android:text`, `android:hint`) MUST NOT contain raw hardcoded strings.
- **String Resources**: Static text must be referenced via string resources (e.g., `android:text="@string/label_chat_now"`).
- **Data Binding**: Dynamic text must use data binding expressions (e.g., `android:text="@{character.name}"`).
- **Editor Previews**: Use `tools:text` (e.g., `tools:text="Preview Name"`) for mock text in the layout editor.
- **Font Padding Parity**: Always set `android:includeFontPadding="false"` on `TextView`s with explicit `lineHeight` to eliminate Android default font padding and achieve 100% typography height match with Figma.
- **Lazy Inflation via ViewStub**: Wrap non-immediate secondary UI blocks (e.g., Error states, Empty view states, Option dialogs) inside `<ViewStub>` to defer layout inflation and reduce screen launch time by 30-50%.

### 1. Responsive Scaling with SDP/SSP
- **Dimension rule**: All spacing, padding, margins, sizes, and font sizes must use SDP (`@dimen/_Xsdp`) and SSP (`@dimen/_Xssp`) libraries to ensure responsiveness.
- **Exceptions**: Use standard `dp`/`sp` only for small fixed elements (e.g., ad icon badges, small action buttons) or when explicitly requested.
- **Font colors & sizes**: Prefer pre-defined text styles in `styles.xml` (e.g., `@style/text_bold_14`, `@style/text_regular_12`) over inline `textColor` and `textSize` declarations.

### 2. Standard Screen Layout Structure
- **Root tag**: Must use `<layout>` for Android DataBinding.
- **Data section**: Include a `<data>` tag for binding variables.
- **Container element**: The primary child of `<layout>` must be a `ConstraintLayout` (commonly with `android:id="@+id/main"`) or a `NestedScrollView` containing a `ConstraintLayout`.
- **Background**: Use custom backgrounds such as `@color/color_bg_main` or drawable assets.
- **Ads section**: Standard screens with ads should contain a `FrameLayout` or `RelativeLayout` with ID `flAds` or `relay_ads`, containing an `<include>` tag referencing the correct shimmer layout (e.g., `@layout/layout_shimmer_native_small`).

### 3. Dynamic Native Ad Layouts
To support dynamic component reordering and visibility control (controlled via Remote Config/Moshi), native ad layouts must follow a strict layout structure:
- **Root tag**: `com.google.android.gms.ads.nativead.NativeAdView`.
- **Direct child**: A vertical `LinearLayout` with ID `ad_container`.
- **Component Blocks**: Inside the `ad_container`, define the following components exactly:
  1. **Icon & Headline Group**: A `ConstraintLayout` with ID `block_icon_headline` wrapping:
     - `ad_app_icon` (ImageView): App/Advertiser icon.
     - `ad_icon` (TextView): The "Ad" badge styled with `@drawable/bg_ad_icon`.
     - `ad_headline` (TextView): Main headline.
     - `ad_advertiser` (TextView): Advertiser text.
  2. **Ad Body**: A `TextView` with ID `ad_body`.
  3. **Ad Media**: A `com.google.android.gms.ads.nativead.MediaView` with ID `ad_media`.
  4. **CTA Button**: An `AppCompatButton` (or similar) with ID `ad_call_to_action`.

*Note: The layout of these blocks inside the XML must match the default ordering, but the container must be a vertical `LinearLayout` to support programmatic reordering.*

### 4. Shimmer Layouts
Shimmer layouts (used during ad loading) must match the design, paddings, and bounds of their corresponding native ad layout. They must use `com.facebook.shimmer.ShimmerFrameLayout` as the root and utilize `@color/lightTransparent` or similar colors for placeholder grey blocks.

---

## Quick Reference Templates

### Standard Activity/Fragment Layout Template
```xml
<?xml version="1.0" encoding="utf-8"?>
<layout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.github.com/tools">

    <data>
        <!-- Data variables here -->
    </data>

    <androidx.constraintlayout.widget.ConstraintLayout
        android:id="@+id/main"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:background="@color/color_bg_main">

        <!-- Toolbar / Header -->
        <TextView
            android:id="@+id/tvTitle"
            style="@style/text_bold_20"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_margin="@dimen/_13sdp"
            android:text="Screen Title"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toTopOf="parent" />

        <!-- Content Area -->
        <androidx.recyclerview.widget.RecyclerView
            android:id="@+id/recyclerView"
            android:layout_width="match_parent"
            android:layout_height="0dp"
            android:layout_marginHorizontal="@dimen/_11sdp"
            android:layout_marginTop="@dimen/_10sdp"
            app:layout_constraintBottom_toTopOf="@id/flAds"
            app:layout_constraintTop_toBottomOf="@id/tvTitle" />

        <!-- Ad Container at the Bottom -->
        <FrameLayout
            android:id="@+id/flAds"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:padding="@dimen/_3sdp"
            app:layout_constraintBottom_toBottomOf="parent">

            <include
                android:id="@+id/shimmerAds"
                layout="@layout/layout_shimmer_native_small"
                android:layout_width="match_parent"
                android:layout_height="wrap_content" />
        </FrameLayout>
    </androidx.constraintlayout.widget.ConstraintLayout>
</layout>
```

### Dynamic Native Ad Layout Template
```xml
<?xml version="1.0" encoding="utf-8"?>
<com.google.android.gms.ads.nativead.NativeAdView xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    tools:ignore="HardcodedText,SpUsage">

    <LinearLayout
        android:id="@+id/ad_container"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="@drawable/bg_native_ads"
        android:orientation="vertical">

        <!-- Block 1: Icon & Headline Group -->
        <androidx.constraintlayout.widget.ConstraintLayout
            android:id="@+id/block_icon_headline"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp">

            <ImageView
                android:id="@+id/ad_app_icon"
                android:layout_width="35dp"
                android:layout_height="35dp"
                android:layout_marginStart="8dp"
                android:adjustViewBounds="true"
                android:contentDescription="@null"
                android:src="@color/colorPrimary"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintTop_toTopOf="parent"
                app:layout_constraintBottom_toBottomOf="parent" />

            <TextView
                android:id="@+id/ad_icon"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginStart="5dp"
                android:background="@drawable/bg_ad_icon"
                android:paddingHorizontal="5dp"
                android:paddingVertical="2dp"
                android:text="Ad"
                android:textColor="#ffffff"
                android:textSize="11dp"
                app:layout_constraintStart_toEndOf="@id/ad_app_icon"
                app:layout_constraintTop_toTopOf="@id/ad_app_icon" />

            <TextView
                android:id="@+id/ad_headline"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_marginStart="2dp"
                android:layout_marginEnd="8dp"
                android:textColor="#000000"
                android:textSize="13dp"
                android:textStyle="bold"
                app:layout_constraintBottom_toBottomOf="@id/ad_icon"
                app:layout_constraintEnd_toEndOf="parent"
                app:layout_constraintStart_toEndOf="@id/ad_icon"
                app:layout_constraintTop_toTopOf="@id/ad_icon"
                tools:text="Headline" />

            <TextView
                android:id="@+id/ad_advertiser"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_marginStart="2dp"
                android:layout_marginTop="2dp"
                android:textColor="#000000"
                android:textSize="13dp"
                android:textStyle="bold"
                app:layout_constraintEnd_toEndOf="@id/ad_headline"
                app:layout_constraintStart_toStartOf="@id/ad_icon"
                app:layout_constraintTop_toBottomOf="@id/ad_headline"
                tools:text="Ad advertiser" />
        </androidx.constraintlayout.widget.ConstraintLayout>

        <!-- Block 2: Body -->
        <TextView
            android:id="@+id/ad_body"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginHorizontal="8dp"
            android:layout_marginTop="12dp"
            android:textColor="#000000"
            android:textSize="13dp"
            tools:text="ad body" />

        <!-- Block 3: Media -->
        <com.google.android.gms.ads.nativead.MediaView
            android:id="@+id/ad_media"
            android:layout_width="match_parent"
            android:layout_height="120dp"
            android:layout_gravity="center_horizontal"
            android:layout_marginHorizontal="8dp"
            android:layout_marginTop="12dp" />

        <!-- Block 4: CTA Button -->
        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/ad_call_to_action"
            android:layout_width="match_parent"
            android:layout_height="40dp"
            android:layout_marginHorizontal="8dp"
            android:layout_marginTop="16dp"
            android:layout_marginBottom="10dp"
            android:background="@drawable/bg_btn_native_cta"
            android:textAllCaps="false"
            android:textColor="#ffffff"
            android:textSize="16dp"
            tools:text="Install" />
    </LinearLayout>
</com.google.android.gms.ads.nativead.NativeAdView>
```

## Common Mistakes & Red Flags

- **Hardcoded text attributes in XML**: Using raw text values directly inside layout XML (like `android:text="Chat Now"`). Always reference `@string/` resource ids or data binding fields instead.
- **Using match_parent inside ConstraintLayout**: Setting `layout_width="match_parent"` or `layout_height="match_parent"` on direct children of `ConstraintLayout` overrides and ignores constraints/paddings. Always use `0dp` (Match Constraint) instead, along with start/end or top/bottom constraints.
- **Using fixed dp sizes for core screen elements**: Using `dp` or `sp` instead of `@dimen/_Xsdp`/`@dimen/_Xssp` degrades responsiveness. Always use the SDP/SSP dimensions for text size, layout margin, and padding.
- **ConstraintLayout hierarchy within NativeAdView**: Using `ConstraintLayout` as the direct container inside `NativeAdView` makes programmatic block reordering difficult. Always use a vertical `LinearLayout` (`ad_container`) as the direct child of `NativeAdView`.
- **Missing DataBinding layout tags**: Creating screen layout files without `<layout>` or `<data>` wrapper tags will cause compile-time binding errors.
- **Inconsistent IDs**: Creating native ad components with custom IDs (like `btn_cta` instead of `ad_call_to_action` or `tv_headline` instead of `ad_headline`) will break runtime ad binding. Use the exact IDs specified.

## Figma Conversion & Layout Overlap Guidelines

- **Overlapping / Underlapping Vectors**: When a Figma design has decorative vectors (like lines, waves, or progress curves) connecting items or running behind text blocks:
  1. Export these vector details individually as PNG/SVG.
  2. Declare the `ImageView` of the connecting vector *before* the overlapping items in the XML file so it is rendered behind them (lower z-order).
  3. Use negative margins (`layout_marginStart="-8dp"` or similar) to stretch the lines behind the adjacent elements and form a continuous visual connection.
- **Coordinate-Based Element Ordering**: Do not trust the default order of nodes in the Figma Layer Tree (JSON children array) when writing XML layouts.
  1. Inspect the absolute bounding box coordinates (`y` for vertical flows, `x` for horizontal flows) of all major layout blocks.
  2. Sort the elements by their coordinate values from top-to-bottom or left-to-right.
  3. Arrange the corresponding XML views/containers in this sorted order to prevent out-of-order component placement (e.g. text labels swapping places with progress bars).
- **Figma SVG & Image Asset Export**: Never use launcher background placeholders or empty views for design assets when figma-mcp-android is available.
  1. **SVG Vector Icons**: Call the `convert_svg_to_android_drawable` tool for all vector nodes. Save them as `app/src/main/res/drawable/ic_[name].xml` and reference them as `@drawable/ic_[name]`.
  2. **Bitmap/Photo Images**: For photos, cards illustrations, and avatar images, call the `get_screenshot` tool to capture the high-resolution PNG. Save them to `app/src/main/res/drawable-xxhdpi/[name].png` and reference them as `@drawable/[name]`.
  3. **No Self-Generated Vectors**: It is STRICTLY FORBIDDEN to guess or self-generate vector XML path data (`android:pathData`) from memory. If the SVG conversion fails or returns invalid paths, you MUST call `get_screenshot` and save the node as a high-res PNG instead of guessing.

## Layout Replacement & Compilation Safety

- **Activity View Bindings Audit**: When replacing an entire layout XML, check the target `Activity`/`Fragment` code for binding references. If base classes require specific IDs (e.g., `fr_banner` for ad integration in `BaseActivityWithBanner`), you must include corresponding placeholder tags with `android:visibility="gone"` or `android:layout_height="0dp"` in the new XML to prevent compile errors.

## Figma API Rate Limit (429) Handling & Fallbacks

When calling Figma API tools (like `download_figma_images` or `get_figma_data`) returns **HTTP Status 429 (Too Many Requests)**, follow these fallback strategies to keep code generation unblocked:

1. **Use Placeholder Assets**: Proceed with code generation using placeholder drawable resources (e.g. `@drawable/ic_launcher_background`, standard Android shapes, or generic vectors like back arrows). Document these placeholders as assumptions so the user can easily swap them later.
2. **Implement Custom Vectors Manually**: For simple, common icons (e.g., arrow back, close, search, checkmark), write the VectorDrawable XML path data directly in code rather than trying to download it.
3. **Download in Batches**: If downloading a list of image nodes, split the requests into smaller batches of 1-3 assets and introduce a delay between calls.
4. **Ask User for Local Files**: If specific graphic assets or screenshots are needed and cannot be fetched, report the rate-limiting error to the user and ask them to manually place the exported files inside the `res/drawable` folder or provide them via chat.

