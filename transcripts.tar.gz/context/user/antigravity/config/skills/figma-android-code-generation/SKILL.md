---
name: figma-android-code-generation
description: Use when converting a Figma design URL or node ID into production-ready Android XML layouts, DataBinding components, drawables, and resource files with empirical build verification.
---

# Figma to Android Layout & Component Generation

## Overview
This skill defines the end-to-end process for converting Figma design nodes into production-ready, DataBinding-enabled Android XML layouts, reusable VectorDrawables, high-resolution bitmap assets, and structured resource tokens with mandatory Gradle build verification.

## When to Use
- Converting a Figma design link (e.g. `https://www.figma.com/design/.../file-name?node-id=XX-YY`) into Android XML layout files.
- Generating new screen layouts or UI component items (RecyclerView cards, dialogs, custom views) from Figma frames.
- Extracting icons, photos, colors, and typography from Figma into Android `res/` resources.

### When NOT to Use
- Non-Android UI projects (Web, Flutter, iOS).
- Modifying backend Kotlin business logic without UI XML layout changes.

---

## Workflow Checklist & Phases

```
┌─────────────────────────────────────────────────────────┐
│ Phase 1: Figma Node Inspection & Visual Rendering      │
├─────────────────────────────────────────────────────────┤
│ Phase 2: Asset Extraction (SVG Vector & Bitmap PNG)     │
├─────────────────────────────────────────────────────────┤
│ Phase 3: Resource Token Mapping (colors.xml & strings) │
├─────────────────────────────────────────────────────────┤
│ Phase 4: Shape & Drawable Asset Generation             │
├─────────────────────────────────────────────────────────┤
│ Phase 5: XML Layout Assembly (DataBinding + SDP/SSP)    │
├─────────────────────────────────────────────────────────┤
│ Phase 6: Empirical Gradle Build Verification            │
└─────────────────────────────────────────────────────────┘
```

### Phase 1: Figma Node Inspection & Visual Rendering
1. **Extract File Key & Node ID**: Parse colon-formatted node ID (e.g., convert `node-id=43-805` to `43:805`).
2. **Fetch Node Data**:
   - Call `figma-mcp-android/get_node` for full node metadata.
   - **CRITICAL RULE 6 (Authoritative Child Node ID Extraction)**: Do NOT guess or infer Node IDs by incrementing/decrementing numerical offsets. Always read the `children` array returned by `get_node` on the parent container frame to extract authoritative child Node IDs.
   - Call `scan_text_nodes` to extract all text strings.
3. **Capture & Inspect Screenshot**:
   - Call `save_screenshots` with `scale: 2` (or 3) to render the target frame to disk.
   - Call `view_file` on the saved screenshot to visually inspect layout hierarchy, colors, spacing, and component relationships.

### Phase 2: Asset Extraction
1. **Vector Icons (SVG)**:
   - **CRITICAL RULE 1 (Node Target)**: Do NOT pass parent row frames or text label Node IDs to `convert_svg_to_android_drawable`. Doing so will fail with `invalid or missing SVG content`.
   - **CRITICAL RULE 2 (Group Child Traversing)**: When an icon is inside a `GROUP` or `FRAME`, do NOT stop at the first `VECTOR` child node. Always inspect the full `children` array of the icon container.
   - **CRITICAL RULE 3 (Multi-path Aggregation)**: If an icon container has multiple sibling `VECTOR` children (e.g., speech bubble outline + inner text lines, or globe circle + meridians + equator), aggregate all `<path>` entries from ALL sibling vector layers into a single VectorDrawable XML so no strokes or details are omitted.
   - Call `convert_svg_to_android_drawable` or assemble full vector path XML with `outputPath` set to `res/drawable/ic_[name].xml`.
2. **Photos & Bitmaps (PNG)**:
   - **CRITICAL RULE 4 (Bitmap Image Node Identification)**: When exporting bitmap photos/illustrations, do NOT select outer card frames or mask group container Node IDs (which often export background shapes like `BG`). Use `get_node` to target the specific child `RECTANGLE` node containing `imageHash` or `type: RECTANGLE` with photo fills.
   - For 3D illustrations, photos, avatars, and complex raster graphics, call `save_screenshots` at scale 3 for the target photo node.
   - Move exported PNG files to `app/src/main/res/drawable-xxhdpi/` (e.g., `img_[name].png`).

### Phase 3: Resource Token Mapping
1. **Colors (`colors.xml`)**:
   - Extract primary, text, background, stroke, and sub-text color hex values from Figma inspection.
   - Add semantically named color resources (e.g. `@color/color_pet_primary`, `@color/color_pet_text`, `@color/color_pet_stroke`) to `res/values/colors.xml`.
2. **Strings (`strings.xml`)**:
   - **STRICT RULE**: Zero hardcoded strings in layout XMLs.
   - Add all user-facing static copy to `res/values/strings.xml` with clear key prefixes (e.g., `@string/pet_sound_title`, `@string/tab_dog`, `@string/nav_translator`).

### Phase 4: Shape & Background Drawables Creation
Create reusable shape XML drawables in `res/drawable/`:
- **CRITICAL RULE 5 (Gradient Fill Detection)**: Inspect `fills` property of card/background nodes in `get_node`. If `type` is `"GRADIENT_LINEAR"`, map `gradientStops` and `gradientTransform` to XML shape `<gradient android:type="linear" android:angle="..." android:startColor="..." android:endColor="..." />` rather than a flat `<solid>` tag.
- `bg_tab_selected.xml` & `bg_tab_unselected.xml` (Segmented tab shapes with corner radius).
- `bg_card_[name]_normal.xml` & `bg_card_[name]_selected.xml` (Card shapes with stroke, corner radius, and solid or linear gradient fill).
- `bg_btn_[name].xml` (Action button background shapes).
- Ring/Circle shapes (e.g. `bg_avatar_outer_ring.xml`, `bg_avatar_inner_ring.xml`).

### Phase 5: XML Layout Assembly
1. **Root Tag**: Must use `<layout>` for DataBinding, wrapping a `<data>` block and primary container (`ConstraintLayout` or `NestedScrollView`).
2. **Responsive Scaling**:
   - Spacing, padding, margins, and sizes MUST use SDP (`@dimen/_Xsdp`).
   - Font sizes MUST use SSP (`@dimen/_Xssp`) or pre-defined text styles (e.g., `@style/text_bold_20`, `@style/text_medium_14`).
3. **Typography Height Parity**:
   - Always set `android:includeFontPadding="false"` on `TextView`s.
4. **Ad Container Integration**:
   - Include FrameLayout `fr_banner` (or `flAds`) with `android:visibility="gone"` for seamless integration with base activity/fragment banner handlers.
5. **Preview Helpers**:
   - Use `tools:text`, `tools:listitem`, `tools:src` for layout editor previews.

### Phase 6: Empirical Gradle Build Verification
1. Run `./gradlew assembleDevDebug` via `run_command`.
2. Verify task completes with exit code 0 (`BUILD SUCCESSFUL`).
3. If build fails (e.g., missing drawable resource or syntax error), immediately fix the underlying issue and re-run verification until passing.

---

## File Naming Conventions

| Asset Type | Directory | Naming Pattern | Example |
|------------|-----------|----------------|---------|
| Vector Icon | `res/drawable/` | `ic_[name].xml` | `ic_setting.xml`, `ic_nav_sound.xml` |
| Bitmap Image | `res/drawable-xxhdpi/` | `img_[name].png` | `img_cat_happy.png`, `img_hero_dog.png` |
| Shape Drawable | `res/drawable/` | `bg_[type]_[name].xml` | `bg_tab_selected.xml`, `bg_card_sound_normal.xml` |
| Screen Layout | `res/layout/` | `activity_[name].xml` | `activity_test.xml`, `activity_pet_sound_detail.xml` |
| Item Layout | `res/layout/` | `item_[name].xml` | `item_pet_sound.xml`, `item_training_news.xml` |

---

## Common Mistakes & Red Flags

- ❌ **Guessing Node IDs by numerical offset**: Attempting `get_node` on guessed ID offsets instead of reading `children` array from parent node causes `Node not found` errors.
- ❌ **Using solid fill for gradient card backgrounds**: Replacing linear gradient fills (`GRADIENT_LINEAR`) with flat `<solid>` colors instead of using `<gradient>`.
- ❌ **Exporting outer frame container for bitmap images**: Exporting card frame or mask group instead of child `imageHash` RECTANGLE node causes exporting wrong background shapes.
- ❌ **Stopping at the first child vector layer**: Fetching only 1 child vector layer of a multi-layer icon container causes missing inner lines/strokes.
- ❌ **Passing parent row frame to SVG converter**: Passing row container node ID instead of leaf vector node ID causes `invalid or missing SVG content`.
- ❌ **Hardcoded raw text in XML**: Using `android:text="Pet Sound"` directly. Always reference `@string/pet_sound_title` and use `tools:text="Pet Sound"`.
- ❌ **Fixed dp for core margins/text**: Using `dp` or `sp` instead of `@dimen/_Xsdp` / `@dimen/_Xssp`.
- ❌ **Missing `<layout>` wrapper**: Creating activity layout without `<layout>` root tag breaks DataBinding generation.
- ❌ **Declaring completion without build verification**: Claiming the layout is done without running `./gradlew assembleDevDebug`.

---

## Rationalization Table

| Excuse | Reality |
|--------|---------|
| "The child node ID should be close to the text node ID" | Figma Node IDs are non-sequential server hashes. Always read parent `children` array to obtain valid Node IDs. |
| "A solid color is close enough to the gradient fill" | Linear gradients add depth and visual excellence to card backgrounds. Always check `fills` for `GRADIENT_LINEAR` and implement `<gradient>`. |
| "The outer card frame contains the image, so I can export it directly" | Outer card frames contain background overlay shapes (`BG`). Always inspect `get_node` and target the child `RECTANGLE` node with `imageHash`. |
| "The first vector child layer looks sufficient" | Multi-layer icons split detail lines across sibling vector nodes. Always traverse the full `children` array and aggregate all `<path>` entries. |
| "The row ID should contain the icon SVG" | Parent row nodes contain text & layout info, not vector paths. Always scan for leaf `VECTOR` / icon `FRAME` nodes. |
